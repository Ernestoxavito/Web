<?php
session_start();
include('conexao.php');
include('functions.php');



// Processar a inserção de doações
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['doar'])) {
    $tipo_sanguineo = $_POST['tipo_sanguineo'];
    $quantidade = $_POST['quantidade'];

    registrarDoacao($tipo_sanguineo, $quantidade);
    echo "<script>alert('Doações registradas com sucesso!');</script>";
}

// Buscar dados para os gráficos
$doacoes = getDoacoes();
$agendamentos = getAgendamentos();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Doações</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <h2>Gestão de Sangue</h2>
            <nav>
                <ul>
                    <li><strong>CADASTROS</strong></li>
                    <li>Agendamentos</li>
                    <li>Doador</li>
                    <li><strong>RELATÓRIOS</strong></li>
                    <li>Dashboard</li>
                    <li>Últimas Doações</li>
                    <li>Listagem</li>
                </ul>
            </nav>
        </aside>

        <main class="dashboard">
            <header>
                <h1>Dashboard</h1>
                <div class="user-profile">
                    <img src="https://via.placeholder.com/40" alt="Usuário">
                    <span><?php echo $_SESSION['usuario']; ?></span>
                </div>
                <a href="logout.php">Sair</a>
            </header>

            <!-- Formulário de Doação -->
            <section class="doacao-form">
                <h2>Registrar Doação</h2>
                <form method="POST">
                    <label for="tipo_sanguineo">Tipo Sanguíneo:</label>
                    <input type="text" name="tipo_sanguineo" required>
                    <label for="quantidade">Quantidade:</label>
                    <input type="number" name="quantidade" required min="1">
                    <button type="submit" name="doar">Registrar Doações</button>
                </form>
            </section>

            <!-- Seção de Gráficos -->
            <section id="graficoSection" class="charts">
                <div class="chart-container">
                    <h3>Doações por Tipo Sanguíneo</h3>
                    <canvas id="doacoesChart"></canvas>
                </div>
                <div class="chart-container">
                    <h3>Agendamentos no Período</h3>
                    <canvas id="agendamentosChart"></canvas>
                </div>
            </section>
        </main>
    </div>

    <script>
        const ctx1 = document.getElementById('doacoesChart').getContext('2d');
        new Chart(ctx1, {
            type: 'doughnut',
            data: {
                labels: ['Novos', 'Recorrentes'],
                datasets: [{
                    data: [70, 30],
                    backgroundColor: ['#1976D2', '#FFB300'],
                    borderWidth: 1
                }]
            },
            options: { responsive: true }
        });

        const ctx2 = document.getElementById('agendamentosChart').getContext('2d');
        new Chart(ctx2, {
            type: 'line',
            data: {
                labels: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio'],
                datasets: [{
                    label: 'Agendamentos',
                    data: [30, 45, 50, 70, 60],
                    fill: false,
                    borderColor: '#FFB300',
                    tension: 0.1
                }]
            },
            options: { responsive: true }
        });
    </script>
</body>
</html>